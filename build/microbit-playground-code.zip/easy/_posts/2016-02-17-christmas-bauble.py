""" 
by Jez Dean / Public Domain
"""

import microbit from *

microbit.display.scroll("ho ho ho")
