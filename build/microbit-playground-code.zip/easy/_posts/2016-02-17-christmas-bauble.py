"""
by Jez Dean / Public Domain
"""

from microbit import *

microbit.display.scroll("ho ho ho")
